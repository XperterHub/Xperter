import { ChromeGlyph } from "@/components/three/ChromeGlyph";
import type { GlyphKind } from "@/components/three/ChromeScene";

export function ComingSoon({ kind, name, index }: { kind: GlyphKind; name: string; index: string }) {
  return (
    <section className="glass relative flex h-full flex-col items-center justify-center overflow-hidden rounded-[1.75rem]">
      <span className="absolute left-8 top-8 text-xs uppercase tracking-[0.3em] text-muted-foreground">{index} — {name}</span>
      <ChromeGlyph kind={kind} className="h-[55vh] w-full max-w-2xl" />
      <h1 className="animate-rise text-5xl md:text-7xl">Coming soon</h1>
      <p className="mt-3 text-sm text-muted-foreground">This space is being polished.</p>
    </section>
  );
}
