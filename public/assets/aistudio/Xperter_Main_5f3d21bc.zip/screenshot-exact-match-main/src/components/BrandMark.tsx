import { Link } from "@tanstack/react-router";
import { APP_NAME } from "@/lib/config";

export function BrandIcon({ size = 56 }: { size?: number }) {
  return (
    <div className="glass flex items-center justify-center rounded-full" style={{ width: size, height: size }}>
      <svg width={size * 0.4} height={size * 0.4} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <circle cx="9.5" cy="12" r="5.5" />
        <circle cx="14.5" cy="12" r="5.5" />
      </svg>
    </div>
  );
}

export function BrandMark() {
  return (
    <Link to="/" className="flex items-center gap-2.5 text-foreground">
      <BrandIcon size={36} />
      <span className="text-sm font-medium tracking-tight">{APP_NAME}</span>
    </Link>
  );
}
