import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, MessageCircle, Phone, Video } from "lucide-react";
import { SilkBackground } from "@/components/SilkBackground";
import { BrandMark } from "@/components/BrandMark";
import { SettingsControl } from "@/components/SettingsControl";
import { ChromeGlyph } from "@/components/three/ChromeGlyph";
import { APP_PAGES } from "@/lib/config";
import type { GlyphKind } from "@/components/three/ChromeScene";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Lumen — Conversations, cast in chrome" },
      { name: "description", content: "An immersive chrome-and-glass space for text, voice and video conversations." },
      { property: "og:title", content: "Lumen — Conversations, cast in chrome" },
      { property: "og:description", content: "An immersive chrome-and-glass space for text, voice and video conversations." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: MessageCircle, title: "Text", body: "Threads that stay calm, quick and readable." },
  { icon: Phone, title: "Voice", body: "One tap to talk. Clear, light, unhurried." },
  { icon: Video, title: "Video", body: "Face to face, framed in frosted glass." },
];

function Landing() {
  return (
    <div className="min-h-screen text-foreground">
      <SilkBackground />
      <header className="fixed inset-x-0 top-0 z-50 flex items-center justify-between px-6 py-5 md:px-10">
        <BrandMark />
        <nav className="glass hidden items-center gap-1 rounded-full p-1 text-sm md:flex">
          <a href="#work" className="liquid-press rounded-full px-4 py-2 hover:bg-glass-strong">Spaces</a>
          <a href="#features" className="liquid-press rounded-full px-4 py-2 hover:bg-glass-strong">Features</a>
          <Link to="/sign-in" className="liquid-press rounded-full px-4 py-2 hover:bg-glass-strong">Sign in</Link>
          <Link to="/sign-up" className="btn-ink liquid-press rounded-full px-4 py-2">Get started</Link>
        </nav>
        <SettingsControl />
      </header>

      <section className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 pt-24">
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <div className="glass animate-blob absolute left-[8%] top-[18%] h-40 w-40 rounded-full" />
          <div className="glass animate-blob absolute right-[10%] top-[26%] h-24 w-24 rounded-full" style={{ animationDelay: "-5s" }} />
          <div className="glass animate-blob absolute bottom-[18%] left-[42%] h-16 w-16 rounded-full" style={{ animationDelay: "-9s" }} />
        </div>
        <ChromeGlyph kind="hero" className="absolute inset-0 cursor-grab" />
        <div className="pointer-events-none relative z-10 flex w-full max-w-7xl flex-col justify-between gap-10 self-stretch md:flex-row md:items-end" style={{ minHeight: "70vh" }}>
          <h1 className="animate-rise text-[14vw] leading-[0.85] md:text-[9vw]">
            Talk,<br /><span className="text-muted-foreground">in chrome.</span>
          </h1>
          <div className="animate-rise pointer-events-auto max-w-xs pb-4" style={{ animationDelay: "0.2s" }}>
            <p className="text-muted-foreground">A quiet, tactile place for text, voice and video — made of glass, light and polished metal. Move your cursor to turn the form.</p>
            <Link to="/sign-up" className="btn-ink liquid-press mt-6 inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm">
              Enter Lumen <ArrowUpRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
        <p className="absolute bottom-6 text-xs uppercase tracking-[0.3em] text-muted-foreground">Scroll</p>
      </section>

      <section id="features" className="mx-auto max-w-7xl px-6 py-32">
        <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">01 — Conversation</p>
        <h2 className="mt-4 max-w-3xl text-5xl md:text-6xl">Every way to reach someone, under one pane of glass.</h2>
        <div className="mt-16 grid gap-5 md:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="glass group rounded-[2.25rem] p-8 transition-transform duration-700 ease-[cubic-bezier(0.34,1.45,0.64,1)] hover:-translate-y-2 hover:scale-[1.02]">
              <div className="btn-ink flex h-12 w-12 items-center justify-center rounded-full transition-transform duration-500 group-hover:rotate-12"><f.icon className="h-5 w-5" /></div>
              <h3 className="mt-10 text-3xl">{f.title}</h3>
              <p className="mt-2 text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="work" className="mx-auto max-w-7xl px-6 pb-32">
        <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">02 — Spaces</p>
        <h2 className="mt-4 text-5xl md:text-6xl">Six spaces. One is open.</h2>
        <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {APP_PAGES.map((p) => (
            <Link key={p.to} to={p.to} className="glass group relative aspect-[4/3] overflow-hidden rounded-[2.25rem] p-6 transition-transform duration-700 ease-[cubic-bezier(0.34,1.45,0.64,1)] hover:scale-[1.02]">
              {"glyph" in p ? <ChromeGlyph kind={p.glyph as GlyphKind} interactive={false} className="absolute inset-0 transition-transform duration-700 group-hover:scale-110" /> : (
                <div className="absolute inset-0 flex items-center justify-center"><MessageCircle className="h-20 w-20 text-muted-foreground transition-transform duration-700 group-hover:scale-110" strokeWidth={1} /></div>
              )}
              <div className="relative flex h-full flex-col justify-between">
                <span className="text-xs text-muted-foreground">{p.short}</span>
                <div className="flex items-end justify-between">
                  <span className="text-2xl font-light">{p.label}</span>
                  <span className="glass rounded-full px-3 py-1 text-xs">{"glyph" in p ? "Coming soon" : "Live"}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <footer className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 border-t border-glass-edge px-6 py-10 text-sm text-muted-foreground md:flex-row">
        <span>© 2026 Lumen</span>
        <div className="flex gap-6"><Link to="/sign-in">Sign in</Link><Link to="/sign-up">Create account</Link><Link to="/app/messages">Workspace</Link></div>
      </footer>
    </div>
  );
}
